////package com.echosense.audio
////
////import android.util.Log
////import kotlin.math.*
////
////class SpeakerDiarizer(private val maxSpeakers: Int = 4) {
////
////    private val audioProcessor = AudioProcessor()
////    private val speakerProfiles = mutableListOf<SpeakerProfile>()
////    private var currentSpeaker: Int? = null
////    private val similarityThreshold = 0.35f  // LOWERED for better detection
////    private val minSpeechAmplitude = 0.02f
////
////    data class SpeakerProfile(
////        val id: Int,
////        val features: MutableList<FloatArray> = mutableListOf(),
////        var lastActiveTime: Long = 0,
////        var totalSamples: Int = 0
////    )
////
////    fun processAudioSegment(audioData: ShortArray, sampleRate: Int, timestamp: Long): Int? {
////        try {
////            // Voice Activity Detection - Skip non-speech
////            if (!isSpeech(audioData)) {
////                return currentSpeaker
////            }
////
////            val features = audioProcessor.extractMFCC(audioData, sampleRate)
////
////            if (features.isEmpty() || features.all { it == 0f }) {
////                return currentSpeaker
////            }
////
////            val speakerId = identifySpeaker(features, timestamp)
////            currentSpeaker = speakerId
////
////            Log.d("SpeakerDiarizer", "🎤 Active Speaker: ${speakerId + 1}, Total: ${speakerProfiles.size}")
////            return speakerId
////
////        } catch (e: Exception) {
////            Log.e("SpeakerDiarizer", "Error in processAudioSegment", e)
////            return currentSpeaker
////        }
////    }
////
////    private fun isSpeech(audioData: ShortArray): Boolean {
////        var energy = 0.0
////        for (sample in audioData) {
////            energy += abs(sample.toDouble())
////        }
////        val avgAmplitude = energy / audioData.size / 32768.0
////        return avgAmplitude > minSpeechAmplitude
////    }
////
////    private fun identifySpeaker(features: FloatArray, timestamp: Long): Int {
////        Log.d("SPEAKER_DEBUG", "=== IDENTIFYING SPEAKER ===")
////
////        if (speakerProfiles.isEmpty()) {
////            Log.d("SPEAKER_DEBUG", "Creating first speaker")
////            return createNewSpeaker(features, timestamp)
////        }
////
////        var bestMatchId = -1
////        var bestSimilarity = -1f
////
////        for (profile in speakerProfiles) {
////            if (profile.features.size < 2) {
////                Log.d("SPEAKER_DEBUG", "Skipping profile ${profile.id} - insufficient features")
////                continue
////            }
////
////            val similarity = cosineSimilarity(features, averageFeatures(profile.features))
////            Log.d("SPEAKER_DEBUG", "Similarity with Speaker ${profile.id + 1}: $similarity")
////
////            if (similarity > bestSimilarity) {
////                bestSimilarity = similarity
////                bestMatchId = profile.id
////            }
////        }
////
////        Log.d("SPEAKER_DEBUG", "Best similarity: $bestSimilarity, Threshold: $similarityThreshold")
////
////        if (bestSimilarity >= similarityThreshold && bestMatchId != -1) {
////            Log.d("SPEAKER_DEBUG", "MATCHED with Speaker ${bestMatchId + 1}")
////            updateSpeakerProfile(bestMatchId, features, timestamp)
////            return bestMatchId
////        } else if (speakerProfiles.size < maxSpeakers) {
////            Log.d("SPEAKER_DEBUG", "CREATING NEW SPEAKER")
////            return createNewSpeaker(features, timestamp)
////        } else {
////            Log.d("SPEAKER_DEBUG", "FALLBACK to Speaker ${if (bestMatchId != -1) bestMatchId + 1 else 1}")
////            return if (bestMatchId != -1) bestMatchId else 0
////        }
////    }
////
////    private fun createNewSpeaker(features: FloatArray, timestamp: Long): Int {
////        val newId = speakerProfiles.size
////        val profile = SpeakerProfile(
////            id = newId,
////            lastActiveTime = timestamp,
////            totalSamples = 1
////        )
////        profile.features.add(features)
////        speakerProfiles.add(profile)
////        Log.d("SPEAKER_DEBUG", "✅ CREATED Speaker ${newId + 1}")
////        return newId
////    }
////
////    private fun updateSpeakerProfile(speakerId: Int, features: FloatArray, timestamp: Long) {
////        val profile = speakerProfiles.find { it.id == speakerId }
////        profile?.let {
////            it.features.add(features)
////            it.lastActiveTime = timestamp
////            it.totalSamples++
////
////            // Keep only recent features
////            if (it.features.size > 20) {
////                it.features.removeAt(0)
////            }
////        }
////    }
////
////    private fun cosineSimilarity(a: FloatArray, b: FloatArray): Float {
////        if (a.size != b.size) return 0f
////
////        var dotProduct = 0.0
////        var normA = 0.0
////        var normB = 0.0
////
////        for (i in a.indices) {
////            dotProduct += a[i] * b[i]
////            normA += a[i] * a[i]
////            normB += b[i] * b[i]
////        }
////
////        return if (normA > 0 && normB > 0) {
////            (dotProduct / (sqrt(normA) * sqrt(normB))).toFloat()
////        } else {
////            0f
////        }
////    }
////
////    private fun averageFeatures(features: List<FloatArray>): FloatArray {
////        if (features.isEmpty()) return FloatArray(0)
////
////        val avg = FloatArray(features[0].size)
////        for (feature in features) {
////            for (i in feature.indices) {
////                avg[i] += feature[i]
////            }
////        }
////        for (i in avg.indices) {
////            avg[i] /= features.size
////        }
////        return avg
////    }
////
////    fun getSpeakerCount(): Int {
////        return speakerProfiles.count { it.totalSamples >= 2 }
////    }
////
////    fun reset() {
////        speakerProfiles.clear()
////        currentSpeaker = null
////        Log.d("SpeakerDiarizer", "Reset complete")
////    }
////}
//
//package com.echosense.audio
//
//import android.util.Log
//import kotlin.math.*
//
//class SpeakerDiarizer(private val maxSpeakers: Int = 4) {
//
//    private val audioProcessor = AudioProcessor()
//    private val speakerProfiles = mutableListOf<SpeakerProfile>()
//    private var currentSpeaker: Int? = null
//    private val similarityThreshold = 0.25f  // LOWERED threshold for better detection
//    private val minSpeechAmplitude = 0.015f  // Lower amplitude threshold
//    private var consecutiveSameSpeaker = 0
//    private var lastSpeakerChangeTime = 0L
//    private val minSpeakerChangeInterval = 2000L // 2 seconds minimum between changes
//
//    data class SpeakerProfile(
//        val id: Int,
//        val features: MutableList<FloatArray> = mutableListOf(),
//        var lastActiveTime: Long = 0,
//        var totalSamples: Int = 0,
//        var speakingDuration: Long = 0
//    )
//
//    fun processAudioSegment(audioData: ShortArray, sampleRate: Int, timestamp: Long): Int? {
//        try {
//            // Voice Activity Detection - Skip non-speech
//            if (!isSpeech(audioData)) {
//                return currentSpeaker
//            }
//
//            val features = audioProcessor.extractMFCC(audioData, sampleRate)
//
//            if (features.isEmpty() || features.all { it == 0f }) {
//                return currentSpeaker
//            }
//
//            val speakerId = identifySpeaker(features, timestamp)
//
//            // Update speaker activity duration
//            speakerId?.let { id ->
//                speakerProfiles.find { it.id == id }?.let { profile ->
//                    profile.speakingDuration += 20 // 20ms per frame
//                }
//            }
//
//            // Only update current speaker if it's a meaningful change
//            if (shouldUpdateSpeaker(speakerId, timestamp)) {
//                currentSpeaker = speakerId
//                Log.d("SpeakerDiarizer", "🎤 Active Speaker: ${speakerId + 1}, Total Profiles: ${speakerProfiles.size}")
//            }
//
//            return currentSpeaker
//
//        } catch (e: Exception) {
//            Log.e("SpeakerDiarizer", "Error in processAudioSegment", e)
//            return currentSpeaker
//        }
//    }
//
//    private fun shouldUpdateSpeaker(newSpeaker: Int?, timestamp: Long): Boolean {
//        if (newSpeaker == null) return false
//        if (currentSpeaker == newSpeaker) {
//            consecutiveSameSpeaker++
//            return false
//        }
//
//        // Prevent rapid speaker switching
//        if (timestamp - lastSpeakerChangeTime < minSpeakerChangeInterval) {
//            return false
//        }
//
//        // Require multiple consecutive detections for speaker change
//        if (consecutiveSameSpeaker < 3) {
//            consecutiveSameSpeaker++
//            return false
//        }
//
//        consecutiveSameSpeaker = 0
//        lastSpeakerChangeTime = timestamp
//        return true
//    }
//
//    private fun isSpeech(audioData: ShortArray): Boolean {
//        var energy = 0.0
//        for (sample in audioData) {
//            energy += abs(sample.toDouble())
//        }
//        val avgAmplitude = energy / audioData.size / 32768.0
//        return avgAmplitude > minSpeechAmplitude
//    }
//
//    private fun identifySpeaker(features: FloatArray, timestamp: Long): Int {
//        if (speakerProfiles.isEmpty()) {
//            Log.d("SPEAKER_DEBUG", "Creating first speaker")
//            return createNewSpeaker(features, timestamp)
//        }
//
//        var bestMatchId = -1
//        var bestSimilarity = -1f
//
//        // Try to match with existing speakers
//        for (profile in speakerProfiles) {
//            if (profile.features.size < 2) {
//                continue
//            }
//
//            val avgFeatures = averageFeatures(profile.features)
//            val similarity = cosineSimilarity(features, avgFeatures)
//
//            Log.d("SIMILARITY_DEBUG", "Similarity with Speaker ${profile.id + 1}: $similarity")
//
//            if (similarity > bestSimilarity) {
//                bestSimilarity = similarity
//                bestMatchId = profile.id
//            }
//        }
//
//        Log.d("SPEAKER_DEBUG", "Best similarity: $bestSimilarity, Threshold: $similarityThreshold")
//
//        // Decision logic
//        return when {
//            bestSimilarity >= similarityThreshold && bestMatchId != -1 -> {
//                Log.d("SPEAKER_DEBUG", "MATCHED with Speaker ${bestMatchId + 1}")
//                updateSpeakerProfile(bestMatchId, features, timestamp)
//                bestMatchId
//            }
//            speakerProfiles.size < maxSpeakers -> {
//                Log.d("SPEAKER_DEBUG", "CREATING NEW SPEAKER")
//                createNewSpeaker(features, timestamp)
//            }
//            else -> {
//                // Fallback: use speaker with most speaking time
//                val mostActiveSpeaker = speakerProfiles.maxByOrNull { it.speakingDuration }?.id ?: 0
//                Log.d("SPEAKER_DEBUG", "FALLBACK to most active speaker: ${mostActiveSpeaker + 1}")
//                mostActiveSpeaker
//            }
//        }
//    }
//
//    private fun createNewSpeaker(features: FloatArray, timestamp: Long): Int {
//        val newId = speakerProfiles.size
//        val profile = SpeakerProfile(
//            id = newId,
//            lastActiveTime = timestamp,
//            totalSamples = 1,
//            speakingDuration = 20
//        )
//        profile.features.add(features)
//        speakerProfiles.add(profile)
//        Log.d("SPEAKER_DEBUG", "✅ CREATED Speaker ${newId + 1}")
//        return newId
//    }
//
//    private fun updateSpeakerProfile(speakerId: Int, features: FloatArray, timestamp: Long) {
//        val profile = speakerProfiles.find { it.id == speakerId }
//        profile?.let {
//            it.features.add(features)
//            it.lastActiveTime = timestamp
//            it.totalSamples++
//
//            // Keep only recent features (sliding window)
//            if (it.features.size > 15) {
//                it.features.removeAt(0)
//            }
//        }
//    }
//
//    private fun cosineSimilarity(a: FloatArray, b: FloatArray): Float {
//        if (a.size != b.size) return 0f
//
//        var dotProduct = 0.0
//        var normA = 0.0
//        var normB = 0.0
//
//        for (i in a.indices) {
//            dotProduct += a[i] * b[i]
//            normA += a[i] * a[i]
//            normB += b[i] * b[i]
//        }
//
//        return if (normA > 0 && normB > 0) {
//            (dotProduct / (sqrt(normA) * sqrt(normB))).toFloat()
//        } else {
//            0f
//        }
//    }
//
//    private fun averageFeatures(features: List<FloatArray>): FloatArray {
//        if (features.isEmpty()) return FloatArray(0)
//
//        val avg = FloatArray(features[0].size)
//        for (feature in features) {
//            for (i in feature.indices) {
//                avg[i] += feature[i]
//            }
//        }
//        for (i in avg.indices) {
//            avg[i] /= features.size
//        }
//        return avg
//    }
//
//    fun getSpeakerCount(): Int {
//        return speakerProfiles.count { it.totalSamples >= 5 } // Require more samples
//    }
//
//    fun getActiveSpeakerProfiles(): List<SpeakerProfile> {
//        return speakerProfiles.filter { it.totalSamples >= 3 }
//    }
//
//    fun reset() {
//        speakerProfiles.clear()
//        currentSpeaker = null
//        consecutiveSameSpeaker = 0
//        lastSpeakerChangeTime = 0L
//        Log.d("SpeakerDiarizer", "Reset complete")
//    }
//}

package com.echosense.audio

import android.util.Log
import kotlin.math.*
import java.util.*

class SpeakerDiarizer(private val maxSpeakers: Int = 4) {

    private val audioProcessor = AudioProcessor()
    private val speakerProfiles = mutableListOf<SpeakerProfile>()
    private var currentSpeaker: Int? = null

    // MUCH LOWER thresholds for better detection
    private val similarityThreshold = 0.15f
    private val minSpeechAmplitude = 0.01f

    // Speaker change prevention
    private var consecutiveSameSpeaker = 0
    private var lastSpeakerChangeTime = 0L
    private val minSpeakerChangeInterval = 1500L // 1.5 seconds

    // Track speaker activity
    private val speakerActivity = mutableMapOf<Int, Long>()

    data class SpeakerProfile(
        val id: Int,
        val features: MutableList<FloatArray> = mutableListOf(),
        var lastActiveTime: Long = 0,
        var totalSamples: Int = 0
    )

    fun processAudioSegment(audioData: ShortArray, sampleRate: Int, timestamp: Long): Int? {
        try {
            // SIMPLIFIED Voice Activity Detection
            if (!isSpeech(audioData)) {
                Log.d("DIARIZATION", "No speech detected")
                return currentSpeaker
            }

            // Extract features
            val features = audioProcessor.extractEnhancedMFCC(audioData, sampleRate)

            if (features.isEmpty() || features.all { it == 0f }) {
                Log.d("DIARIZATION", "No features extracted")
                return currentSpeaker
            }

            Log.d("DIARIZATION", "Features extracted: ${features.size} coefficients")

            // Identify speaker
            val speakerId = identifySpeaker(features, timestamp)

            // Update activity tracking
            speakerId?.let { id ->
                speakerActivity[id] = (speakerActivity[id] ?: 0) + 1
            }

            Log.d("DIARIZATION", "Identified speaker: $speakerId, Current: $currentSpeaker")

            return speakerId

        } catch (e: Exception) {
            Log.e("SpeakerDiarizer", "Error in audio processing", e)
            return currentSpeaker
        }
    }

    private fun isSpeech(audioData: ShortArray): Boolean {
        // Simple energy-based VAD
        var energy = 0.0
        for (sample in audioData) {
            energy += abs(sample.toDouble())
        }
        val avgAmplitude = energy / audioData.size / 32768.0

        val isSpeech = avgAmplitude > minSpeechAmplitude
        Log.d("VAD", "Amplitude: $avgAmplitude, Threshold: $minSpeechAmplitude, IsSpeech: $isSpeech")

        return isSpeech
    }

    private fun identifySpeaker(features: FloatArray, timestamp: Long): Int {
        Log.d("SPEAKER_ID", "=== Identifying Speaker ===")

        // Create first speaker if none exist
        if (speakerProfiles.isEmpty()) {
            Log.d("SPEAKER_ID", "Creating first speaker")
            return createNewSpeaker(features, timestamp)
        }

        var bestMatchId = -1
        var bestSimilarity = -1f

        // Compare with all existing speakers
        for (profile in speakerProfiles) {
            if (profile.features.size < 2) {
                Log.d("SPEAKER_ID", "Skipping profile ${profile.id} - insufficient features")
                continue
            }

            val similarity = cosineSimilarity(features, averageFeatures(profile.features))
            Log.d("SPEAKER_ID", "Similarity with Speaker ${profile.id + 1}: $similarity")

            if (similarity > bestSimilarity) {
                bestSimilarity = similarity
                bestMatchId = profile.id
            }
        }

        Log.d("SPEAKER_ID", "Best similarity: $bestSimilarity, Threshold: $similarityThreshold")

        // Decision logic
        return when {
            bestSimilarity >= similarityThreshold && bestMatchId != -1 -> {
                Log.d("SPEAKER_ID", "✅ MATCHED with Speaker ${bestMatchId + 1}")
                updateSpeakerProfile(bestMatchId, features, timestamp)
                bestMatchId
            }
            speakerProfiles.size < maxSpeakers -> {
                Log.d("SPEAKER_ID", "🆕 CREATING NEW SPEAKER")
                createNewSpeaker(features, timestamp)
            }
            else -> {
                // Use most active speaker as fallback
                val mostActive = speakerActivity.maxByOrNull { it.value }?.key ?: 0
                Log.d("SPEAKER_ID", "🔄 FALLBACK to most active speaker: ${mostActive + 1}")
                mostActive
            }
        }
    }

    private fun createNewSpeaker(features: FloatArray, timestamp: Long): Int {
        val newId = speakerProfiles.size
        val profile = SpeakerProfile(
            id = newId,
            lastActiveTime = timestamp,
            totalSamples = 1
        )
        profile.features.add(features)
        speakerProfiles.add(profile)
        speakerActivity[newId] = 1

        Log.d("SPEAKER_CREATE", "✅ CREATED Speaker ${newId + 1}")
        Log.d("SPEAKER_CREATE", "Total speakers now: ${speakerProfiles.size}")

        return newId
    }

    private fun updateSpeakerProfile(speakerId: Int, features: FloatArray, timestamp: Long) {
        val profile = speakerProfiles.find { it.id == speakerId }
        profile?.let {
            it.features.add(features)
            it.lastActiveTime = timestamp
            it.totalSamples++

            // Keep only recent features (sliding window)
            if (it.features.size > 10) {
                it.features.removeAt(0)
            }
        }
    }

    private fun cosineSimilarity(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size) return 0f

        var dotProduct = 0.0
        var normA = 0.0
        var normB = 0.0

        for (i in a.indices) {
            dotProduct += a[i] * b[i]
            normA += a[i] * a[i]
            normB += b[i] * b[i]
        }

        return if (normA > 0 && normB > 0) {
            (dotProduct / (sqrt(normA) * sqrt(normB))).toFloat()
        } else {
            0f
        }
    }

    private fun averageFeatures(features: List<FloatArray>): FloatArray {
        if (features.isEmpty()) return FloatArray(0)

        val avg = FloatArray(features[0].size)
        for (feature in features) {
            for (i in feature.indices) {
                avg[i] += feature[i]
            }
        }
        for (i in avg.indices) {
            avg[i] /= features.size
        }
        return avg
    }

    fun getSpeakerCount(): Int {
        return speakerProfiles.count { it.totalSamples >= 3 }
    }

    fun getActiveSpeakers(): List<Int> {
        return speakerProfiles.map { it.id }
    }

    fun reset() {
        speakerProfiles.clear()
        speakerActivity.clear()
        currentSpeaker = null
        consecutiveSameSpeaker = 0
        lastSpeakerChangeTime = 0L
        Log.d("SpeakerDiarizer", "🔄 Reset complete")
    }
}