
package com.echosense.viewmodels

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.echosense.audio.AudioProcessor
import com.example.echosense.audio.AudioRecorder
import com.echosense.audio.SpeakerDiarizer
import com.echosense.db.AppDatabase
import com.echosense.models.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.asCoroutineDispatcher
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors
import kotlin.math.abs

data class LiveCaptureUiState(
    val isRecording: Boolean = false,
    val isPaused: Boolean = false,
    val isListening: Boolean = false,
    val activeSpeaker: Int? = null,
    val currentAmplitude: Float = 0f,
    val transcriptEntries: List<TranscriptEntry> = emptyList(),
    val currentPartialText: String = "",
    val showEndDialog: Boolean = false,
    val recognitionMode: String = "Initializing...",
    val errorMessage: String = "",
    val processingStatus: String = "Ready",
    val maxSpeakers: Int = 4,
    val detectedSpeakers: Int = 0  // NEW: Track detected speakers in real-time
)

class LiveCaptureViewModel(private val maxSpeakers: Int = 4) : ViewModel() {

    private val TAG = "LiveCaptureVM"

    // Single-thread dispatcher for Vosk calls
    private val voskDispatcher = Executors.newSingleThreadExecutor().asCoroutineDispatcher()

    private val _uiState = MutableStateFlow(LiveCaptureUiState(maxSpeakers = maxSpeakers))
    val uiState: StateFlow<LiveCaptureUiState> = _uiState.asStateFlow()

    private val audioRecorder = AudioRecorder()
    private val audioProcessor = AudioProcessor()
    private lateinit var speakerDiarizer: SpeakerDiarizer
    private var currentContext: Context? = null

    private var currentSessionId: Long = 0
    private var audioFile: File? = null
    private var recordingStartTime: Long = 0
    private var currentDatabase: AppDatabase? = null

    // Vosk offline STT
    private var voskModel: Model? = null
    private var voskRecognizer: Recognizer? = null
    private var isModelLoaded = false

    // Accumulator to buffer several frames before feeding to Vosk
    private val voskAccumulator = ByteArrayOutputStream()
    private val MIN_BYTES_FOR_VOSK = 3200

    // Speaker tracking
    private val createdSpeakers = mutableSetOf<Long>()

    init {
        speakerDiarizer = SpeakerDiarizer(maxSpeakers = maxSpeakers)
    }

    fun startRecording(context: Context) {
        currentContext = context

        viewModelScope.launch(Dispatchers.IO) {
            val db = AppDatabase.getDatabase(context)
            currentDatabase = db

            val session = Session(
                title = "Conversation ${SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()).format(Date())}",
                startTime = System.currentTimeMillis(),
                endTime = null,
                speakerCount = 0,
                duration = 0L,
                audioFilePath = null,
                isCompleted = false
            )
            currentSessionId = db.sessionDao().insertSession(session)

            audioFile = File(context.filesDir, "audio_$currentSessionId.pcm")

            // Register audio listeners
            audioRecorder.addAudioDataListener { frame ->
                processAudioData(frame)
            }
            audioRecorder.addAmplitudeListener { amplitude ->
                _uiState.value = _uiState.value.copy(currentAmplitude = amplitude)
            }

            recordingStartTime = System.currentTimeMillis()
            val started = audioRecorder.startRecording(audioFile)

            withContext(Dispatchers.Main) {
                _uiState.value = _uiState.value.copy(
                    isRecording = started,
                    processingStatus = if (started) "Audio recording started" else "Failed to start"
                )
            }

            if (!started) return@launch

            delay(500)

            // Load Vosk model in background
            loadVoskModelSafely(context)
        }
    }

    // CRITICAL FIX: Ensure speaker exists in database
    private fun ensureSpeakerExists(speakerId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Check if we already created this speaker in this session
                if (createdSpeakers.contains(speakerId)) {
                    return@launch
                }

                val existingSpeaker = currentDatabase?.sessionDao()?.getSpeaker(currentSessionId, speakerId)

                if (existingSpeaker == null) {
                    // Create new speaker entity
                    val colors = listOf(
                        0xFF00BCD4.toInt(), 0xFFFF9800.toInt(), 0xFF9C27B0.toInt(),
                        0xFF4CAF50.toInt(), 0xFFE91E63.toInt(), 0xFFFFEB3B.toInt()
                    )
                    val color = colors[(speakerId % colors.size).toInt()]

                    val speaker = Speaker(
                        id = speakerId,  // Use the same ID as in diarization
                        sessionId = currentSessionId,
                        speakerLabel = "Speaker ${speakerId + 1}",
                        color = color,
                        speakingPercentage = 0f,
                        totalSpeakingTime = 0L
                    )

                    currentDatabase?.sessionDao()?.insertSpeaker(speaker)
                    createdSpeakers.add(speakerId)

                    // Update UI with current speaker count
                    val speakerCount = currentDatabase?.sessionDao()?.getSpeakerCount(currentSessionId) ?: 0
                    withContext(Dispatchers.Main) {
                        _uiState.value = _uiState.value.copy(detectedSpeakers = speakerCount)
                    }

                    Log.d(TAG, "✅ CREATED Speaker ${speakerId + 1} in database. Total: $speakerCount")
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error creating speaker", e)
            }
        }
    }

    private fun updateSpeakerDetection(audioData: ShortArray, timestamp: Long) {
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val speakerId = speakerDiarizer.processAudioSegment(
                    audioData,
                    audioRecorder.getSampleRate(),
                    timestamp
                )

                Log.d(TAG, "🎯 Diarizer returned speaker: $speakerId")

                if (speakerId != null) {
                    // ENSURE SPEAKER EXISTS IN DATABASE
                    ensureSpeakerExists(speakerId.toLong())

                    // Only update UI if speaker actually changed
                    if (speakerId != _uiState.value.activeSpeaker) {
                        withContext(Dispatchers.Main) {
                            _uiState.value = _uiState.value.copy(activeSpeaker = speakerId)
                            Log.d(TAG, "🔄 SPEAKER CHANGE: ${speakerId + 1}")
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Speaker diarization error", e)
            }
        }
    }
    private suspend fun loadVoskModelSafely(context: Context) = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "Starting Vosk model loading...")
            _uiState.value = _uiState.value.copy(processingStatus = "Loading speech model...")

            val modelDir = File(context.filesDir, "vosk-model-small-en-us-0.15")

            if (!modelDir.exists() || !File(modelDir, "am/final.mdl").exists()) {
                Log.d(TAG, "Extracting model from assets...")
                _uiState.value = _uiState.value.copy(processingStatus = "Extracting model (first time)...")
                extractAssetToStorage(context, "vosk-model-small-en-us-0.15", modelDir)
                Log.d(TAG, "Model extracted successfully")
            }

            if (!verifyModelFiles(modelDir)) {
                throw IOException("Model files incomplete or corrupted")
            }

            Log.d(TAG, "Loading Vosk model from: ${modelDir.absolutePath}")
            _uiState.value = _uiState.value.copy(processingStatus = "Initializing speech engine...")

            voskModel = Model(modelDir.absolutePath)
            val sampleRate = audioRecorder.getSampleRate().toFloat()
            voskRecognizer = Recognizer(voskModel, sampleRate)

            isModelLoaded = true
            Log.d(TAG, "Vosk model loaded successfully (${sampleRate}Hz)")

            withContext(Dispatchers.Main) {
                _uiState.value = _uiState.value.copy(
                    recognitionMode = "Offline (Vosk)",
                    processingStatus = "Ready - Speak now",
                    isListening = true,
                    errorMessage = ""
                )
            }

        } catch (e: OutOfMemoryError) {
            Log.e(TAG, "Out of memory loading Vosk model", e)
            handleModelLoadFailure("Out of memory - Model too large")
        } catch (e: IOException) {
            Log.e(TAG, "IO error loading Vosk model", e)
            handleModelLoadFailure("Model files not found or corrupted")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load Vosk model", e)
            handleModelLoadFailure("Failed to load model: ${e.message}")
        }
    }

    private fun extractAssetToStorage(context: Context, assetPath: String, targetDir: File) {
        val assetManager = context.assets
        val files = assetManager.list(assetPath) ?: return

        if (!targetDir.exists()) targetDir.mkdirs()

        for (name in files) {
            val fullAssetPath = "$assetPath/$name"
            val outFile = File(targetDir, name)

            val children = assetManager.list(fullAssetPath)
            if (children != null && children.isNotEmpty()) {
                extractAssetToStorage(context, fullAssetPath, outFile)
            } else {
                assetManager.open(fullAssetPath).use { input ->
                    outFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                }
            }
        }
    }

    private fun verifyModelFiles(modelDir: File): Boolean {
        val requiredFiles = listOf(
            "am/final.mdl",
            "conf/mfcc.conf",
            "conf/model.conf",
            "graph/HCLr.fst",
            "graph/Gr.fst"
        )

        for (file in requiredFiles) {
            if (!File(modelDir, file).exists()) {
                Log.e(TAG, "Missing required file: $file")
                return false
            }
        }
        return true
    }

    private suspend fun handleModelLoadFailure(message: String) = withContext(Dispatchers.Main) {
        _uiState.value = _uiState.value.copy(
            recognitionMode = "Speaker Detection Only",
            processingStatus = "STT unavailable",
            errorMessage = message,
            isListening = true
        )
    }

//    private fun processAudioData(frame: ShortArray) {
//        if (_uiState.value.isPaused) return
//
//        viewModelScope.launch(Dispatchers.Default) {
//            val timeFromStart = System.currentTimeMillis() - recordingStartTime
//
//            try {
//                // SPEAKER DIARIZATION
//                val speakerId = speakerDiarizer.processAudioSegment(
//                    frame,
//                    audioRecorder.getSampleRate(),
//                    timeFromStart
//                )
//
//                Log.d(TAG, "🎯 Diarizer returned speaker: $speakerId")
//
//                if (speakerId != null) {
//                    // ENSURE SPEAKER EXISTS IN DATABASE
//                    ensureSpeakerExists(speakerId.toLong())
//
//                    if (speakerId != _uiState.value.activeSpeaker) {
//                        withContext(Dispatchers.Main) {
//                            _uiState.value = _uiState.value.copy(activeSpeaker = speakerId)
//                            Log.d(TAG, "🔄 SPEAKER CHANGE: ${speakerId + 1}")
//                        }
//                    }
//                }
//
//                // Convert for Vosk
//                val bytes = frame.toByteArrayLE()
//
//                // Feed Vosk
//                if (isModelLoaded && voskRecognizer != null) {
//                    synchronized(voskAccumulator) {
//                        voskAccumulator.write(bytes)
//                    }
//
//                    if (voskAccumulator.size() < MIN_BYTES_FOR_VOSK) return@launch
//
//                    val chunk: ByteArray
//                    synchronized(voskAccumulator) {
//                        chunk = voskAccumulator.toByteArray()
//                        voskAccumulator.reset()
//                    }
//
//                    viewModelScope.launch(voskDispatcher) {
//                        try {
//                            val isFinal = voskRecognizer!!.acceptWaveForm(chunk, chunk.size)
//                            if (isFinal) {
//                                val jsonStr = voskRecognizer!!.result
//                                handleVoskJson(jsonStr, true)
//                            } else {
//                                val jsonStr = voskRecognizer!!.partialResult
//                                handleVoskJson(jsonStr, false)
//                            }
//                        } catch (e: Exception) {
//                            Log.e(TAG, "Vosk processing error", e)
//                        }
//                    }
//                }
//            } catch (e: Exception) {
//                Log.e(TAG, "Audio processing error", e)
//            }
//        }
//    }

    private fun processAudioData(frame: ShortArray) {
        if (_uiState.value.isPaused) return

        viewModelScope.launch(Dispatchers.Default) {
            val timeFromStart = System.currentTimeMillis() - recordingStartTime

            try {
                // SPEAKER DIARIZATION - Process immediately
                val speakerId = speakerDiarizer.processAudioSegment(
                    frame,
                    audioRecorder.getSampleRate(),
                    timeFromStart
                )

                Log.d(TAG, "🎯 DIARIZATION RESULT: Speaker ${(speakerId ?: -1) + 1}")

                if (speakerId != null) {
                    // ENSURE SPEAKER EXISTS IN DATABASE
                    ensureSpeakerExists(speakerId.toLong())

                    // Update UI immediately
                    if (speakerId != _uiState.value.activeSpeaker) {
                        withContext(Dispatchers.Main) {
                            _uiState.value = _uiState.value.copy(activeSpeaker = speakerId)
                            Log.d(TAG, "🔄 SPEAKER CHANGED TO: ${speakerId + 1}")
                        }
                    }
                }

            } catch (e: Exception) {
                Log.e(TAG, "Speaker diarization error", e)
            }

            // Continue with Vosk processing...
            val bytes = frame.toByteArrayLE()

            if (isModelLoaded && voskRecognizer != null) {
                synchronized(voskAccumulator) {
                    voskAccumulator.write(bytes)
                }

                if (voskAccumulator.size() < MIN_BYTES_FOR_VOSK) return@launch

                val chunk: ByteArray
                synchronized(voskAccumulator) {
                    chunk = voskAccumulator.toByteArray()
                    voskAccumulator.reset()
                }

                viewModelScope.launch(voskDispatcher) {
                    try {
                        val isFinal = voskRecognizer!!.acceptWaveForm(chunk, chunk.size)
                        if (isFinal) {
                            val jsonStr = voskRecognizer!!.result
                            handleVoskJson(jsonStr, true)
                        } else {
                            val jsonStr = voskRecognizer!!.partialResult
                            handleVoskJson(jsonStr, false)
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Vosk processing error", e)
                    }
                }
            }
        }
    }

    private fun debugSpeakerState(audioData: ShortArray, speakerId: Int?) {
        val amplitude = audioData.map { abs(it.toDouble()) }.average() / 32768.0
        Log.d("DEBUG_SPEAKER",
            "Amplitude: $amplitude, " +
                    "Speaker: ${speakerId?.plus(1) ?: "None"}, " +
                    "Total Speakers: ${speakerDiarizer.getSpeakerCount()}"
        )
    }

    private suspend fun handleVoskJson(jsonStr: String?, isFinal: Boolean) {
        if (jsonStr == null) return

        try {
            val obj = JSONObject(jsonStr)

            if (!isFinal && obj.has("partial")) {
                val partial = obj.getString("partial")
                if (partial.isNotBlank()) {
                    withContext(Dispatchers.Main) {
                        _uiState.value = _uiState.value.copy(
                            currentPartialText = partial,
                            processingStatus = "Recognizing..."
                        )
                    }
                }
            }

            if (isFinal && obj.has("text")) {
                val text = obj.getString("text")
                if (text.isNotBlank()) {
                    Log.d(TAG, "Recognized: '$text'")
                    addTranscriptEntry(text, 0.85f)

                    withContext(Dispatchers.Main) {
                        _uiState.value = _uiState.value.copy(
                            currentPartialText = "",
                            processingStatus = "Added transcript"
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "JSON parse error", e)
        }
    }

    private fun addTranscriptEntry(text: String, confidence: Float) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val currentTime = System.currentTimeMillis() - recordingStartTime
                val speakerId = _uiState.value.activeSpeaker?.toLong() ?: 0L

                // Ensure speaker exists before creating transcript
                ensureSpeakerExists(speakerId)

                val entry = TranscriptEntry(
                    sessionId = currentSessionId,
                    speakerId = speakerId,
                    speakerLabel = "Speaker ${speakerId + 1}",
                    text = text,
                    timestamp = currentTime,
                    duration = text.split(" ").size * 400L,
                    confidence = confidence
                )

                currentDatabase?.sessionDao()?.insertTranscriptEntry(entry)
                val currentEntries = _uiState.value.transcriptEntries.toMutableList()
                currentEntries.add(entry)

                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(
                        transcriptEntries = currentEntries
                    )
                }

                Log.d(TAG, "📝 Transcript added for Speaker ${speakerId + 1}: $text")
            } catch (e: Exception) {
                Log.e(TAG, "Error adding transcript", e)
            }
        }
    }

    fun togglePause() {
        val isPaused = !_uiState.value.isPaused
        _uiState.value = _uiState.value.copy(
            isPaused = isPaused,
            isListening = !isPaused,
            processingStatus = if (isPaused) "Paused" else "Listening..."
        )
    }

    fun addBookmark() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val currentTime = System.currentTimeMillis() - recordingStartTime
                val bookmark = Note(
                    sessionId = currentSessionId,
                    type = NoteType.BOOKMARK,
                    content = "Bookmark at ${formatTime(currentTime)}",
                    timestamp = currentTime
                )
                currentDatabase?.noteDao()?.insertNote(bookmark)

                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(processingStatus = "Bookmark added")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error adding bookmark", e)
            }
        }
    }

    private fun formatTime(millis: Long): String {
        val seconds = millis / 1000
        val minutes = seconds / 60
        return String.format("%02d:%02d", minutes, seconds % 60)
    }

    fun showEndDialog() {
        _uiState.value = _uiState.value.copy(showEndDialog = true)
    }

    fun dismissEndDialog() {
        _uiState.value = _uiState.value.copy(showEndDialog = false)
    }

    fun endRecording(context: Context, onComplete: (Long) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                audioRecorder.stopRecording()
                Log.d(TAG, "Audio recorder stopped")
            } catch (e: Exception) {
                Log.e(TAG, "Error stopping recorder", e)
            }

            // Close Vosk resources
            try {
                voskRecognizer?.close()
                voskRecognizer = null
                Log.d(TAG, "Recognizer closed")
            } catch (e: Exception) {
                Log.e(TAG, "Error closing recognizer", e)
            }

            try {
                voskModel?.close()
                voskModel = null
                isModelLoaded = false
                Log.d(TAG, "Model closed")
            } catch (e: Exception) {
                Log.e(TAG, "Error closing model", e)
            }

            try {
                val db = currentDatabase ?: AppDatabase.getDatabase(context)
                val endTime = System.currentTimeMillis()
                val duration = endTime - recordingStartTime

                // GET REAL SPEAKER COUNT FROM DATABASE
                val actualSpeakerCount = db.sessionDao().getUniqueSpeakerCount(currentSessionId)
                Log.d(TAG, "🎉 FINAL SPEAKER COUNT: $actualSpeakerCount")

                val s = db.sessionDao().getSession(currentSessionId)
                s?.let {
                    val updated = it.copy(
                        endTime = endTime,
                        duration = duration,
                        speakerCount = actualSpeakerCount,  // REAL COUNT!
                        audioFilePath = audioFile?.absolutePath,
                        isCompleted = true
                    )
                    db.sessionDao().updateSession(updated)
                }

                // Extract notes from transcript
                val transcript = db.sessionDao().getTranscriptForSession(currentSessionId)
                if (transcript.isNotEmpty()) {
                    val extractor = com.echosense.ml.NoteExtractor()
                    val notes = extractor.extractNotes(transcript, currentSessionId)
                    notes.forEach { note -> db.noteDao().insertNote(note) }
                }

                withContext(Dispatchers.Main) {
                    onComplete(currentSessionId)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error saving session", e)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        try {
            voskRecognizer?.close()
            voskModel?.close()
            audioRecorder.stopRecording()
            try {
                (voskDispatcher.executor as? java.util.concurrent.ExecutorService)?.shutdownNow()
            } catch (_: Exception) {}
            Log.d(TAG, "ViewModel cleared")
        } catch (e: Exception) {
            Log.e(TAG, "Error in onCleared", e)
        }
    }

    // Helper functions
    private fun ShortArray.toByteArrayLE(): ByteArray {
        val b = ByteArray(this.size * 2)
        var idx = 0
        for (s in this) {
            val v = s.toInt()
            b[idx++] = (v and 0xFF).toByte()
            b[idx++] = ((v shr 8) and 0xFF).toByte()
        }
        return b
    }
}
