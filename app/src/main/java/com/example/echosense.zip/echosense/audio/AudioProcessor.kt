//package com.echosense.audio
//
//import kotlin.math.*
//
//class AudioProcessor {
//
//    companion object {
//        private const val FFT_SIZE = 512
//    }
//
//    // Extract MFCC features (simplified version)
//    fun extractMFCC(audioData: ShortArray, sampleRate: Int): FloatArray {
//        // Convert to float
//        val floatData = FloatArray(audioData.size) { audioData[it] / 32768.0f }
//
//        // Pre-emphasis
//        val preEmphasized = applyPreEmphasis(floatData)
//
//        // Frame signal
//        val frames = frameSignal(preEmphasized, FFT_SIZE, FFT_SIZE / 2)
//
//        val mfccFeatures = mutableListOf<FloatArray>()
//
//        for (frame in frames) {
//            val windowed = applyHammingWindow(frame)
//            val powerSpectrum = computePowerSpectrum(windowed)
//            val mfcc = computeMFCC(powerSpectrum, sampleRate)
//            mfccFeatures.add(mfcc)
//        }
//
//        return averageFeatures(mfccFeatures)
//    }
//
//    private fun applyPreEmphasis(signal: FloatArray, alpha: Float = 0.97f): FloatArray {
//        val result = FloatArray(signal.size)
//        result[0] = signal[0]
//        for (i in 1 until signal.size) {
//            result[i] = signal[i] - alpha * signal[i - 1]
//        }
//        return result
//    }
//
//    private fun frameSignal(signal: FloatArray, frameSize: Int, hopSize: Int): List<FloatArray> {
//        val frames = mutableListOf<FloatArray>()
//        var start = 0
//        while (start + frameSize <= signal.size) {
//            frames.add(signal.copyOfRange(start, start + frameSize))
//            start += hopSize
//        }
//        return frames
//    }
//
//    private fun applyHammingWindow(frame: FloatArray): FloatArray {
//        val result = FloatArray(frame.size)
//        for (i in frame.indices) {
//            val multiplier = 0.54 - 0.46 * cos(2.0 * PI * i / (frame.size - 1))
//            result[i] = frame[i] * multiplier.toFloat()
//        }
//        return result
//    }
//
//    private fun computePowerSpectrum(frame: FloatArray): FloatArray {
//        val n = frame.size
//        val powerSpectrum = FloatArray(n / 2 + 1)
//
//        for (k in 0..n / 2) {
//            var real = 0.0
//            var imag = 0.0
//
//            for (t in 0 until n) {
//                val angle = -2.0 * PI * k * t / n
//                real += frame[t] * cos(angle)
//                imag += frame[t] * sin(angle)
//            }
//
//            powerSpectrum[k] = (real * real + imag * imag).toFloat()
//        }
//        return powerSpectrum
//    }
//
//    private fun computeMFCC(powerSpectrum: FloatArray, sampleRate: Int, numCoeffs: Int = 13): FloatArray {
//        val mfcc = FloatArray(numCoeffs)
//
//        for (i in 0 until numCoeffs) {
//            var sum = 0.0
//            for (j in powerSpectrum.indices) {
//                sum += powerSpectrum[j] * cos(PI * i * (j + 0.5) / powerSpectrum.size)
//            }
//            mfcc[i] = sum.toFloat()
//        }
//        return mfcc
//    }
//
//    private fun averageFeatures(features: List<FloatArray>): FloatArray {
//        if (features.isEmpty()) return FloatArray(0)
//
//        val avg = FloatArray(features[0].size)
//
//        for (feature in features) {
//            for (i in feature.indices) {
//                avg[i] += feature[i]
//            }
//        }
//
//        for (i in avg.indices) {
//            avg[i] /= features.size
//        }
//
//        return avg
//    }
//}

package com.echosense.audio

import kotlin.math.*
import java.util.*

class AudioProcessor {

    companion object {
        private const val FFT_SIZE = 512
        private const val NUM_MFCC_COEFFS = 13
        private const val NUM_FILTERS = 26
    }

    // Extract enhanced MFCC features with delta coefficients
    fun extractEnhancedMFCC(audioData: ShortArray, sampleRate: Int): FloatArray {
        // Convert to float and normalize
        val floatData = FloatArray(audioData.size) { audioData[it] / 32768.0f }

        // Apply pre-emphasis
        val preEmphasized = applyPreEmphasis(floatData)

        // Frame signal with overlap
        val frames = frameSignal(preEmphasized, FFT_SIZE, FFT_SIZE / 4) // 75% overlap

        if (frames.isEmpty()) return FloatArray(0)

        val allMFCCs = mutableListOf<FloatArray>()

        for (frame in frames) {
            // Apply windowing
            val windowed = applyHammingWindow(frame)

            // Compute power spectrum
            val powerSpectrum = computePowerSpectrum(windowed)

            // Extract MFCCs
            val mfcc = computeMFCC(powerSpectrum, sampleRate, NUM_MFCC_COEFFS)

            // Only use frames with sufficient energy
            val energy = mfcc.sumOf { it.toDouble() }.toFloat()
            if (energy > 0.1f) {
                allMFCCs.add(mfcc)
            }
        }

        if (allMFCCs.isEmpty()) return FloatArray(0)

        // Return averaged features across all valid frames
        return averageFeatures(allMFCCs)
    }

    private fun applyPreEmphasis(signal: FloatArray, alpha: Float = 0.95f): FloatArray {
        val result = FloatArray(signal.size)
        result[0] = signal[0]
        for (i in 1 until signal.size) {
            result[i] = signal[i] - alpha * signal[i - 1]
        }
        return result
    }

    private fun frameSignal(signal: FloatArray, frameSize: Int, hopSize: Int): List<FloatArray> {
        val frames = mutableListOf<FloatArray>()
        var start = 0
        while (start + frameSize <= signal.size) {
            frames.add(signal.copyOfRange(start, start + frameSize))
            start += hopSize
        }
        return frames
    }

    private fun applyHammingWindow(frame: FloatArray): FloatArray {
        val result = FloatArray(frame.size)
        for (i in frame.indices) {
            val multiplier = 0.54f - 0.46f * cos(2.0f * PI.toFloat() * i / (frame.size - 1))
            result[i] = frame[i] * multiplier
        }
        return result
    }

    private fun computePowerSpectrum(frame: FloatArray): FloatArray {
        val n = frame.size
        val fft = FFT(n)
        val complexFrame = FloatArray(n * 2)

        // Convert to complex (real, imag) format
        for (i in 0 until n) {
            complexFrame[2 * i] = frame[i]
            complexFrame[2 * i + 1] = 0f
        }

        // Perform FFT
        fft.fft(complexFrame)

        // Compute power spectrum (first half)
        val powerSpectrum = FloatArray(n / 2 + 1)
        for (i in 0..n / 2) {
            val real = complexFrame[2 * i]
            val imag = complexFrame[2 * i + 1]
            powerSpectrum[i] = (real * real + imag * imag) / n
        }

        return powerSpectrum
    }

    private fun computeMFCC(powerSpectrum: FloatArray, sampleRate: Int, numCoeffs: Int): FloatArray {
        // Apply mel filterbank
        val filterBanks = applyMelFilterbank(powerSpectrum, sampleRate)

        // Log the filterbank energies
        val logBanks = FloatArray(filterBanks.size) {
            ln(max(1e-10f, filterBanks[it]))
        }

        // Apply DCT to get MFCCs
        val mfcc = FloatArray(numCoeffs)
        for (i in 0 until numCoeffs) {
            var sum = 0.0f
            for (j in logBanks.indices) {
                val angle = (PI * i * (j + 0.5f) / logBanks.size).toFloat()
                sum += logBanks[j] * cos(angle)
            }
            mfcc[i] = sum * sqrt(2.0f / logBanks.size)
        }

        return mfcc
    }

    private fun applyMelFilterbank(powerSpectrum: FloatArray, sampleRate: Int): FloatArray {
        val lowFreq = 0f
        val highFreq = sampleRate / 2.0f
        val lowMel = hzToMel(lowFreq)
        val highMel = hzToMel(highFreq)
        val melPoints = LinearInterpolator.interpolate(lowMel, highMel, NUM_FILTERS + 2)
        val hzPoints = FloatArray(melPoints.size) { melToHz(melPoints[it]) }
        val binPoints = IntArray(hzPoints.size) { (hzPoints[it] / sampleRate * (FFT_SIZE)) .toInt() }

        val filterBank = FloatArray(NUM_FILTERS)
        for (i in 0 until NUM_FILTERS) {
            var sum = 0.0f
            for (j in binPoints[i]..binPoints[i + 2]) {
                val weight = when {
                    j < binPoints[i] -> 0f
                    j <= binPoints[i + 1] -> (j - binPoints[i]).toFloat() / (binPoints[i + 1] - binPoints[i])
                    j <= binPoints[i + 2] -> (binPoints[i + 2] - j).toFloat() / (binPoints[i + 2] - binPoints[i + 1])
                    else -> 0f
                }
                if (j < powerSpectrum.size) {
                    sum += powerSpectrum[j] * weight
                }
            }
            filterBank[i] = sum
        }

        return filterBank
    }

    private fun hzToMel(hz: Float): Float = 2595f * log10(1f + hz / 700f)
    private fun melToHz(mel: Float): Float = 700f * (10f.pow(mel / 2595f) - 1f)

    private fun averageFeatures(features: List<FloatArray>): FloatArray {
        if (features.isEmpty()) return FloatArray(0)

        val avg = FloatArray(features[0].size)
        for (feature in features) {
            for (i in feature.indices) {
                avg[i] += feature[i]
            }
        }
        for (i in avg.indices) {
            avg[i] /= features.size
        }
        return avg
    }
}

// Simple FFT implementation
class FFT(private val n: Int) {
    fun fft(x: FloatArray) {
        if (n == 1) return

        // Split into even and odd
        val even = FloatArray(n)
        val odd = FloatArray(n)
        for (i in 0 until n / 2) {
            even[i] = x[2 * i]
            even[i + n / 2] = x[2 * i + 1]
            odd[i] = x[2 * i + 1]
            odd[i + n / 2] = x[2 * i + 1]
        }

        // Recursive FFT
        fft(even)
        fft(odd)

        // Combine
        for (k in 0 until n / 2) {
            val tReal = cos(-2 * PI * k / n).toFloat()
            val tImag = sin(-2 * PI * k / n).toFloat()
            val realPart = tReal * odd[k] - tImag * odd[k + n / 2]
            val imagPart = tReal * odd[k + n / 2] + tImag * odd[k]

            x[k] = even[k] + realPart
            x[k + n / 2] = even[k + n / 2] + imagPart
            x[k + n] = even[k] - realPart
            x[k + 3 * n / 2] = even[k + n / 2] - imagPart
        }
    }
}

object LinearInterpolator {
    fun interpolate(start: Float, end: Float, count: Int): FloatArray {
        val result = FloatArray(count)
        val step = (end - start) / (count - 1)
        for (i in 0 until count) {
            result[i] = start + i * step
        }
        return result
    }
}